create database javaTestDB;
use javaTestDB;
CREATE USER javauser IDENTIFIED BY 'javapass'; 
grant usage on *.* to javauser@localhost identified by 'javapass'; 
grant all privileges on javaTestDB.* to javauser@localhost;

CREATE TABLE PERSON_RECORD (
	ID INT NOT NULL AUTO_INCREMENT,
	NAME VARCHAR(15) NOT NULL,
	SURNAME VARCHAR(15) NOT NULL,
	SALARY INT(15) NOT NULL,
	JOIN_DATE DATE NOT NULL,
	PRIMARY KEY (ID)
);



ALTER TABLE PERSON_RECORD AUTO_INCREMENT = 1

ALTER TABLE PERSON_RECORD ADD COLUMN RDP_PASS TinyInt(1); //for adding bool or boolean type

