package com.validation;

public class EmailValidation {

	public EmailValidation() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args){
		System.out.println("Name : Sanjay_Kumar@Das.com : "+ validateEmail("Sanjay_Kumar@Das.com"));
		System.out.println("Name : Sanjay @123 : "+ validateEmail("Sanjay @123"));
		System.out.println("Name : Sanjay123/ : "+ validateEmail("Sanjay123/"));
	}
	
	private static boolean validateEmail(String email) {
		//validate email
		if (email.matches("^[_A-Za-z](.*)([@]{1})(.{1,})(\\.)(.{1,})")) 
			return true;
		return false;
	}

}
