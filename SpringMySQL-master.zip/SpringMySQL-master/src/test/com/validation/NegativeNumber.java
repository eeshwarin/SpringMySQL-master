package com.validation;

public class NegativeNumber {

	public NegativeNumber() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		System.out.println("-1 : "+ validateNegativeNumber(-1));
		System.out.println("0 : "+ validateNegativeNumber(0));
		System.out.println("1 : "+ validateNegativeNumber(1));
	}
	
	private static boolean validateNegativeNumber(int number) {
		//validate negative number
		if (number >= 0) 
			return true;
		return false;
	}

}
