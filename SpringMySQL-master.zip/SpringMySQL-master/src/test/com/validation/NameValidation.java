package com.validation;

//Only Alphabets and space is allowed
//Numbers and special chars and others not allowed
public class NameValidation {

	public NameValidation() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		System.out.println("Name : Sanjay Kumar Das : "+ validateName("Sanjay Kumar Das"));
		System.out.println("Name : Sanjay @123 : "+ validateName("Sanjay @123"));
		System.out.println("Name : Sanjay123/ : "+ validateName("Sanjay123/"));

	}
	
	private static boolean validateName(String name) {
		//validate phone numbers of format "alphabets and space"
		if (name.matches("^[A-Za-z\\s]+$")) 
			return true;
		return false;
	}

}
