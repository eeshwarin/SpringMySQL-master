package com.dimitrisli.springMySQL.exception;

public class InvalidPersonNameException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidPersonNameException(String message) {
		super(message);
	}

}
