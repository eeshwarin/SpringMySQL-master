package com.dimitrisli.springMySQL.dao;

import java.util.Date;
import java.util.List;

import com.dimitrisli.springMySQL.exception.DuplicatePrimaryKeyException;
import com.dimitrisli.springMySQL.model.Person;


public interface PersonDao {

	public void createPerson(long id, String name, String surname, long Salary, Date joinDate, boolean pass) throws DuplicatePrimaryKeyException;
	public Person selectPerson(String name, String surname);
	public List<Person> selectAll();
	public void updatePerson(String name, int salary);
	public void deletePerson(String name, String surname);
	public void deleteAll();
	public int findTotalPersons();
}
