package com.dimitrisli.springMySQL.dao;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.dimitrisli.springMySQL.exception.DuplicatePrimaryKeyException;
import com.dimitrisli.springMySQL.model.Person;

public class PersonDaoImpl implements PersonDao{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	//private CustomerExceptionTranslator customerExceptionTranslator;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public DataSource getDataSource() {
		return dataSource;
	}
	
	public void setDataSource(DataSource dataSource){
		this.dataSource = dataSource;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	/*public CustomerExceptionTranslator getCustomerExceptionTranslator() {
		return customerExceptionTranslator;
	}

	public void setCustomerExceptionTranslator(
			CustomerExceptionTranslator customerExceptionTranslator) {
		this.customerExceptionTranslator = customerExceptionTranslator;
		this.jdbcTemplate.setExceptionTranslator(customerExceptionTranslator);
	}*/

	@Transactional
	public void createPerson(long id, String name, String surname, long salary, Date joinDate, boolean pass) throws DuplicatePrimaryKeyException {
		
		try{
			
			String sql = "INSERT INTO PERSON_RECORD (ID,NAME,SURNAME,SALARY,JOIN_DATE,RDP_PASS) VALUES (?,?,?,?,?,?)";
		
			this.jdbcTemplate.update(sql, new Object[]{id,name,surname,salary,joinDate,pass});
			
			}catch (BadSqlGrammarException e) {
	            System.out.println("BadSqlGrammarException" + e.getMessage());
	        }catch(DuplicateKeyException ex){
	        	System.out.println("DuplicateKeyException" + ex.getMessage());
	        	throw new DuplicatePrimaryKeyException("Duplicate Primary Key Exception!");
			}catch(DataAccessException ex){
				System.out.println("DataAccessException->" + ex.getMessage());
			}	
		
	}

	public Person selectPerson(String name, String surname) {
		
		Person person = null;
		String sql = "SELECT * FROM PERSON_RECORD WHERE NAME=? AND SURNAME=?";
		
		//person = this.jdbcTemplate.queryForObject(sql, new Object[]{name, surname}, new PersonRowMapper());
		
		//return person;
		try{
			person = this.jdbcTemplate.queryForObject(sql, new Object[]{name, surname}, new PersonRowMapper());
			
		}catch (BadSqlGrammarException e) {
            System.out.println("BadSqlGrammarException->" + e.getMessage() + ",SQL Code->" + ((SQLException)e.getCause()).getErrorCode());
        }catch(EmptyResultDataAccessException ex){
        	System.out.println("EmptyResultDataAccessException-> " + ex.getMessage());
		}catch(DataAccessException ex){
        	System.out.println("DataAccessException-> " + ex.getMessage());
		}
		return person;
	}

	public List<Person> selectAll() throws EmptyResultDataAccessException {

		List<Person> personList = null;
		String sql = "SELECT * FROM PERSON_RECORD";
		//try{
		
			personList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Person>(Person.class));
		
			if(personList.size() == 0){
					throw new EmptyResultDataAccessException(personList.size());
			}
		/*}catch(DataAccessException ex){
			ex.getMessage();
		}*/
		return personList;
		
	}
	
	public void updatePerson(String name, int salary){
	      String sql = "UPDATE PERSON_RECORD SET SALARY=? WHERE NAME=?";
	      this.jdbcTemplate.update(sql, salary, name);

	   }

	public void deletePerson(String name, String surname) throws DataAccessException{

		String sql = "DELETE FROM PERSON_RECORD WHERE NAME=? AND SURNAME=?";
		int rowsAffeced = this.jdbcTemplate.update(sql, new Object[]{name, surname});
		System.out.println("Delete Particular Person : rowsAffeced : "+rowsAffeced);

	}

	public void deleteAll() {
		String sql = "DELETE FROM PERSON_RECORD";
		int rowsAffeced = this.jdbcTemplate.update(sql);
		System.out.println("Delete All RowsAffeced : "+rowsAffeced);
	}
	
	public int findTotalPersons(){

		String sql = "SELECT COUNT(*) FROM PERSON_RECORD";

		return getJdbcTemplate().queryForInt(sql);
	}

}
