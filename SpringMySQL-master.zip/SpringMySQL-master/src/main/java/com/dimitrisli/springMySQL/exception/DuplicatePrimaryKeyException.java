package com.dimitrisli.springMySQL.exception;

public class DuplicatePrimaryKeyException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DuplicatePrimaryKeyException(String message) {
		super(message);
		
	}

}
