package com.dimitrisli.springMySQL.test;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dimitrisli.springMySQL.exception.DuplicatePrimaryKeyException;
import com.dimitrisli.springMySQL.exception.InvalidPersonNameException;
import com.dimitrisli.springMySQL.service.PersonServiceImpl;

public class Main {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring/config/beanLocations.xml");

		PersonServiceImpl personService = (PersonServiceImpl) context.getBean("personService");
		
		System.out.println("------Records Creation--------");

		/*List<Person> personList = new ArrayList<Person>();
		
		Person p1 = new Person();
		p1.setId(1);
		p1.setName("Sunney");
		p1.setSurname("Deol");
		p1.setSalary(40000);
		p1.setJoinDate(addDays(new Date(), 0));
		p1.setRdpPass(true);
		
		Person p2 = new Person();
		p2.setId(2);
		p2.setName("michalis");
		p2.setSurname("liapis");
		p2.setSalary(20000);
		p2.setJoinDate(addDays(new Date(), 1));
		p2.setRdpPass(false);
		
		Person p3 = new Person();
		p3.setId(3);
		p3.setName("kostas");
		p3.setSurname("georgiou");
		p3.setSalary(40000);
		p3.setJoinDate(addDays(new Date(), 2));
		p3.setRdpPass(false);
		
		personList.add(p1);
		personList.add(p2);
		personList.add(p3);
		
		personService.createPersonList(personList);*/
		try{
		personService.createPerson(1,"Sunney", "Deol", 40000, addDays(new Date(), 0),true);
		
		/*personService.createPerson(2,"michalis", "liapis", 20000, addDays(new Date(), 1),false);
		personService.createPerson(3,"kostas", "liapis", 30000, addDays(new Date(), 2),true);
		personService.createPerson(4,"stella", "georgiou", 40000, addDays(new Date(), 3),false);*/
		
		}catch(InvalidPersonNameException ex){
			System.out.println(ex.getMessage());
		}catch(DuplicatePrimaryKeyException ex){
			System.out.println(ex.getMessage());
		}
		
		
		/*System.out.println("------Fetching All Records--------");
		try{
		List<Person> personList = personService.selectAll();
		if(personList !=null && personList.size()>0){
			for(Person currentPerson : personService.selectAll()){
				System.out.println("From DB: name="+currentPerson.getName()+", surname="+currentPerson.getSurname()+ ", Salary="+currentPerson.getSalary()+", Join Date="+
						currentPerson.getJoinDate()+", RDP Pass="+currentPerson.isRdpPass());
			}
		}else{
			System.out.println("RECORDS NOT FOUND IN DATABASE");
		}
		}catch(EmptyResultDataAccessException ex){
			System.out.println("RECORDS NOT FOUND IN DATABASE" +ex.getMessage());
		}*/
		
		/*System.out.println("------Selecting particular Record------");
		Person selectPerson = personService.selectPerson("sanjay", "liapis");
		if(selectPerson != null){
			System.out.println("From DB: name="+selectPerson.getName()+", surname="+selectPerson.getSurname());
		}else {
			System.out.println("DATA NOT FOUND IN DATABASE");
		}*/
		
		
		/*System.out.println("------Person Record Counts--------");
		try{
			int personCounts = personService.findTotalPersons();
			System.out.println(personCounts);
				
		} catch (DuplicateKeyException e) {
			System.out.println("Forum Already Exist");
		} catch (DataAccessException e) {
			e.printStackTrace();
		}*/
		
		/*System.out.println("------Updating Record------");
		try{
			personService.updatePerson("dimitris", 50000);
			
			System.out.println("------Listing Multiple Records--------");
			for(Person currentPerson : personService.selectAll()){
				System.out.println("From DB: name="+currentPerson.getName()+", surname="+currentPerson.getSurname()+ ", Salary="+currentPerson.getSalary()+", Join Date="+
						currentPerson.getJoinDate()+", RDP Pass="+currentPerson.isRdpPass());
			}
		} catch (DuplicateKeyException e) {
			System.out.println("Forum Already Exist");
		} catch (DataAccessException e) {
			e.printStackTrace();
		}*/
		
		
		
		
		/*System.out.println("------Deleting Particular Record------");
		personService.deletePerson("sanjaya", "liapis");
		for(Person currentPerson : personService.selectAll()){
			System.out.println("From DB: name="+currentPerson.getName()+", surname="+currentPerson.getSurname());
		}*/
		
		
		/*System.out.println("------Deleting All Records------");
		personService.deleteAll();*/
		
	}
	//Date utility
	
			/*{
		        Date now = new Date();
		        Date now1 = new Date();
		        Date now2 = new Date();
		        DateFormat currentDate = DateFormat.getDateInstance();

		        Date addedDate1 = addDays(now2, 20);
		        Date addedDate2 = addDays(now1, 30);
		        System.out.println(currentDate.format(now));
		        System.out.println(currentDate.format(addedDate1));
		        System.out.println(currentDate.format(addedDate2));
		    }*/
	public static Date addDays(Date d, int days)
    {
        d.setTime(d.getTime() + days * 1000 * 60 * 60 * 24);
        
        return d;
        
    }
}
