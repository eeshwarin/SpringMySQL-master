package com.dimitrisli.springMySQL.bo;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;

import com.dimitrisli.springMySQL.dao.PersonDaoImpl;
import com.dimitrisli.springMySQL.exception.DataNotFoundException;
import com.dimitrisli.springMySQL.exception.DuplicatePrimaryKeyException;
import com.dimitrisli.springMySQL.exception.InvalidPersonNameException;
import com.dimitrisli.springMySQL.model.Person;

public class PersonBO {

	public PersonBO() {}
	
	@Autowired
	private PersonDaoImpl personDao;

	/*public PersonDaoImpl getPersonDao() {
		return personDao;
	}
	public void setPersonDao(PersonDaoImpl personDao) {
		this.personDao = personDao;
	}*/

	public void createPerson(int id, String name, String surname, long salary, Date joinDate, boolean pass) throws InvalidPersonNameException, DuplicatePrimaryKeyException {
		
		//String regexPersonName = "^[A-Za-z\\s]+$";
		//Pattern pattern = Pattern.compile(regexPersonName);
		//Matcher matcher = pattern.matcher(name);
		
		//if(matcher.matches()){
		if(name.matches("^[a-zA-Z\\s]+$")){

			this.personDao.createPerson(id, name, surname, salary, joinDate, pass);

		} else {
			throw new InvalidPersonNameException("Invalid Person Name!");
		}
			
	}
	
	public List<Person> selectAll() throws DataNotFoundException, EmptyResultDataAccessException {
		
		return this.personDao.selectAll();

	}
	
	public Person selectPerson(String name, String surname) throws DataNotFoundException {
		Person person = null;
		person = personDao.selectPerson(name, surname);
		if(person!= null){
			return person;
		}else{
			throw new DataNotFoundException("Data Not Found in Database");
		}
	}
	
	public void updatePerson(String name, int salary){
		personDao.updatePerson(name, salary);
	}
	
	public void deletePerson(String name, String surname){
		personDao.deletePerson(name, surname);
	}
	
	public void deleteAll(){
		personDao.deleteAll();
	}
	
	public int findTotalPersons(){
		return personDao.findTotalPersons();
	}

}
