package com.dimitrisli.springMySQL.service;

import java.util.Date;
import java.util.List;

import com.dimitrisli.springMySQL.exception.DataNotFoundException;
import com.dimitrisli.springMySQL.exception.DuplicatePrimaryKeyException;
import com.dimitrisli.springMySQL.exception.InvalidPersonNameException;
import com.dimitrisli.springMySQL.model.Person;

public interface PersonService {
	
	public void createPerson(int id, String name, String surname, long salary, Date joinDate, boolean pass) throws InvalidPersonNameException, DuplicatePrimaryKeyException;
	//public void createPersonList(List personList) throws InvalidPersonNameException;
	public Person selectPerson(String name, String surname) throws DataNotFoundException;
	public List<Person> selectAll() throws DataNotFoundException;
	public void updatePerson(String name, int salary);
	public void deletePerson(String name, String surname);
	public void deleteAll();
	public int findTotalPersons();

}
