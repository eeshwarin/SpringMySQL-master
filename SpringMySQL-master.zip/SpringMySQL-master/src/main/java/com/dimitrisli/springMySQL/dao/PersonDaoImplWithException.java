package com.dimitrisli.springMySQL.dao;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.dimitrisli.springMySQL.exception.CustomerExceptionTranslator;
import com.dimitrisli.springMySQL.model.Person;

public class PersonDaoImplWithException{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	//private CustomerExceptionTranslator customerExceptionTranslator;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public DataSource getDataSource() {
		return dataSource;
	}
	
	public void setDataSource(DataSource dataSource){
		this.dataSource = dataSource;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	/*public CustomerExceptionTranslator getCustomerExceptionTranslator() {
		return customerExceptionTranslator;
	}

	public void setCustomerExceptionTranslator(
			CustomerExceptionTranslator customerExceptionTranslator) {
		this.customerExceptionTranslator = customerExceptionTranslator;
		this.jdbcTemplate.setExceptionTranslator(customerExceptionTranslator);
	}*/

	public void createPerson(long id, String name, String surname, long salary, Date joinDate, boolean pass) {
		/*JdbcTemplate createPerson = new JdbcTemplate(dataSource);
		createPerson.update("INSERT INTO PERSON_RECORD (NAME,SURNAME,SALARY,JOIN_DATE,RDP_PASS) VALUES (?,?,?,?,?)",
				new Object[]{name,surname,salary,joinDate,pass});*/
		
		/*String sql = "INSERT INTO PERSON_RECORD (NAME,SURNAME,SALARY,JOIN_DATE,RDP_PASS) VALUES (?,?,?,?,?)";
		this.jdbcTemplate.update(sql, new Object[]{name,surname,salary,joinDate,pass});*/
		
		try{
		
			String sql = "INSERT INTO PERSON_RECORD (ID,NAME,SURNAME,SALARY,JOIN_DATE,RDP_PASS) VALUES (?,?,?,?,?,?)";
		
			this.jdbcTemplate.update(sql, new Object[]{id,name,surname,salary,joinDate,pass});
			
		}catch (BadSqlGrammarException e) {
            System.out.println("BadSqlGrammarException" + e.getMessage());
        }catch(DuplicateKeyException ex){
        	System.out.println("DuplicateKeyException" + ex.getMessage());
		}catch(DataAccessException ex){
			System.out.println("DataAccessException->" + ex.getMessage());
		}
	}

	public Person selectPerson(String name, String surname) {
		/*JdbcTemplate selectPerson = new JdbcTemplate(dataSource);
		return selectPerson.query("SELECT NAME,SURNAME FROM PERSON_RECORD WHERE NAME=? AND SURNAME=?",
				new Object[] {name,surname},
				new PersonRowMapper());
		return selectPerson.query("SELECT * FROM PERSON_RECORD WHERE NAME=? AND SURNAME=?",
				new Object[] {name,surname},
				new PersonRowMapper());*/
		
		Person person = null;
		String sql = "SELECT * FROM PERSON_RECORD WHERE NAME=? AND SURNAME=?";
		
		try{
			person = this.jdbcTemplate.queryForObject(sql, new Object[]{name, surname}, new PersonRowMapper());
			
		}catch (BadSqlGrammarException e) {
            System.out.println("BadSqlGrammarException->" + e.getMessage() + ",SQL Code->" + ((SQLException)e.getCause()).getErrorCode());
        }catch(EmptyResultDataAccessException ex){
        	System.out.println("EmptyResultDataAccessException-> " + ex.getMessage());
		}catch(DataAccessException ex){
        	System.out.println("DataAccessException-> " + ex.getMessage());
		}
		return person;
		//return this.jdbcTemplate.queryForObject(sql, new Object[]{name, surname}, new PersonRowMapper());
		//return person;
	}

	public List<Person> selectAll() {
		//JdbcTemplate selectPerson = new JdbcTemplate(dataSource);
		/*return selectPerson.query("SELECT NAME,SURNAME FROM PERSON_RECORD",
				new PersonRowMapper());*/
		/*return selectPerson.query("SELECT * FROM PERSON_RECORD",
				new PersonRowMapper());*/
		List<Person> personList = null;
		try{
		String sql = "SELECT * FROM PERSON_RECORD";
		//return this.jdbcTemplate.query(sql, new PersonRowMapper());
		personList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Person>(Person.class));
		
		if(personList.size() == 0){
			try {
				throw new EmptyResultDataAccessException(personList.size());
			} catch (EmptyResultDataAccessException e) {
				// TODO Auto-generated catch block
				System.out.println("EmptyResultDataAccessException-> " + e.getMessage());
			}
		}
		
		}catch (BadSqlGrammarException e) {
            System.out.println("BadSqlGrammarException->" + e.getMessage());
        }catch(DataAccessException ex){
        	System.out.println("DataAccessException-> " + ex.getMessage());
		}
		return personList;
		
	}
	
	public void updatePerson(String name, int salary){
	      String sql = "UPDATE PERSON_RECORD SET SALARY=? WHERE NAME=?";
	      this.jdbcTemplate.update(sql, salary, name);

	   }

	public void deletePerson(String name, String surname) throws DataAccessException{
		/*JdbcTemplate deletePerson = new JdbcTemplate(dataSource);
		deletePerson.update("DELETE FROM PERSON_RECORD WHERE NAME=? AND SURNAME=?",
				new Object[]{name,surname});	*/
		//try{
		String sql = "DELETE FROM PERSON_RECORD WHERE NAME=? AND SURNAME=?";
		int rowsAffeced = this.jdbcTemplate.update(sql, new Object[]{name, surname});
		System.out.println("rowsAffeced : "+rowsAffeced);
		/*}catch (BadSqlGrammarException e) {
            System.out.println("DataAccessException->BadSqlGrammarException" + e.getMessage() + ",SQL Code->" + ((SQLException)e.getCause()).getErrorCode());
            //return null;
        }catch(DataAccessException ex){
        	System.out.println("DataAccessException->EmptyResultDataAccessException" + ex.getMessage() + ",SQL Code->" + ((SQLException)ex.getCause()).getErrorCode());
			//return null;
		}*/
	}

	public void deleteAll() {
		/*JdbcTemplate deleteAll = new JdbcTemplate(dataSource);
		deleteAll.update("DELETE FROM PERSON_RECORD");*/
		String sql = "DELETE FROM PERSON_RECORD";
		this.jdbcTemplate.update(sql);
	}
	
	public int findTotalPersons(){

		String sql = "SELECT COUNT(*) FROM PERSON_RECORD";

		return getJdbcTemplate().queryForInt(sql);
	}

}
