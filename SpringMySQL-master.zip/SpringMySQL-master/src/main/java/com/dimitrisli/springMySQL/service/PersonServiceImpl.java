package com.dimitrisli.springMySQL.service;

import java.util.Date;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;

import com.dimitrisli.springMySQL.bo.PersonBO;
import com.dimitrisli.springMySQL.exception.DataNotFoundException;
import com.dimitrisli.springMySQL.exception.DuplicatePrimaryKeyException;
import com.dimitrisli.springMySQL.exception.InvalidPersonNameException;
import com.dimitrisli.springMySQL.model.Person;


public class PersonServiceImpl implements PersonService{

	private PersonBO personBO;
	
	public PersonServiceImpl(PersonBO personBO) {
		super();
		this.personBO = personBO;
	}

	/*public PersonBO getPersonBO() {
		return personBO;
	}
	public void setPersonBO(PersonBO personBO) {
		this.personBO = personBO;
	}*/
	
	public void createPerson(int id, String name, String surname, long salary, Date joinDate, boolean pass) throws InvalidPersonNameException, DuplicatePrimaryKeyException{
		personBO.createPerson(id, name, surname, salary, joinDate, pass);
	}
	
	public List<Person> selectAll() throws DataNotFoundException, EmptyResultDataAccessException {
		List<Person> personList = null;
		//try{
			personList = personBO.selectAll();
		/*}catch(DataNotFoundException ex){
			ex.getMessage();
		}*/
		return personList;
	}
	
	public Person selectPerson(String name, String surname) throws DataNotFoundException {
		
		Person person = null;
		try{
			person = personBO.selectPerson(name, surname);
		}catch(DataNotFoundException ex){
			ex.getMessage();
		}
		
		return person;
	}
	
	public void updatePerson(String name, int salary){
		personBO.updatePerson(name, salary);
	}
	
	public void deletePerson(String name, String surname){
		personBO.deletePerson(name, surname);
	}
	
	public void deleteAll(){
		personBO.deleteAll();
	}
	
	public int findTotalPersons(){
		return personBO.findTotalPersons();
	}

}
